package com.example.senha;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText loginView, senhaView;
    private String login, senha;
    private final String loginMestre = "Mestre Andre", chaveMestre = "Pizza";
    private TextView mensagemErro;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void verificaAcesso(View view){
        loginView = findViewById(R.id.login);
        senhaView = findViewById(R.id.senha);
        mensagemErro = findViewById(R.id.mensagemErro);
        mensagemErro.setTextColor(Color.RED);
        login = loginView.getText().toString();
        senha = senhaView.getText().toString();

        checaAcesso();
    }

    private void checaAcesso(){
        if(login.equals(loginMestre) && senha.equals(chaveMestre)){
            Toast.makeText(this, "Acesso CONCEDIDO!", Toast.LENGTH_SHORT).show();
            Intent it = new Intent(MainActivity.this, NovaTela.class);
            startActivity(it);
        }else if(login.isEmpty() || senha.isEmpty()){
            Toast.makeText(this, "CAMPOS VAZIOS", Toast.LENGTH_SHORT).show();
            mensagemErro.setText("Acesso negado! campos vazios");
        }else{
            Toast.makeText(this, "Acesso NEGADO!", Toast.LENGTH_SHORT).show();
            mensagemErro.setText("Acesso negado! login ou senha incorretas");
        }
    }
}