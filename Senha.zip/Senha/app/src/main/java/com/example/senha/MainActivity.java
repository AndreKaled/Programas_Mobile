package com.example.senha;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private TextView loginView, senhaView, resultadoView;
    private String login, senha, loginMestre = "Mestre Andre", chaveMestre = "Pizza";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void acessar(View view){
        loginView = findViewById(R.id.login);
        senhaView = findViewById(R.id.senha);

        login = loginView.getText().toString();
        senha = senhaView.getText().toString();

        verificaAcesso();
    }

    private void verificaAcesso(){
        resultadoView = findViewById(R.id.resultado);

        if(login.equals(loginMestre) && senha.equals(chaveMestre)){
            resultadoView.setText("Acesso permitido");
            Intent intent = new Intent(MainActivity.this, NovaTela.class);
            startActivity(intent);
        }else{
            resultadoView.setText("Acesso negado");
        }
    }
}