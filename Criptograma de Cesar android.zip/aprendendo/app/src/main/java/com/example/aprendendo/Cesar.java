package com.example.aprendendo;

public class Cesar {
    public static String codificaCesar(String frase, int chave) {
        char c;
        char p = 32;
        String cripto = "";
        for (int i = 0; i < frase.length(); i++) {
            c = frase.charAt(i);

            // caso minuscula
            if (c > 96 && c < 123) {
                p = (char) (c + chave);
                if ((char) p > 122) {
                    p = (char) (p - 26);
                }
            } else if (c > 64 && c < 91) { // caso maiuscula
                p = (char) (c + chave);
                if ((char) p >= 65) {
                    p = (char) (p - 26);
                }
            } else { // todos os outros casos
                p = c;
            }

            String letra = "";
            letra += p;
            cripto = cripto.concat(letra);
        }
        return cripto;
    }

    public static String descriptografiaDeCesar(String codigo, int chave) {
        char c;
        char p = 32;
        String descript = "";
        for (int i = 0; i < codigo.length(); i++) {
            c = codigo.charAt(i);

            if (c > 96 && c < 123) { // caso minuscula
                p = (char) (c - chave);
                if ((char) p <= 96) {
                    p = (char) (p + 26);
                }
            } else if (c > 64 && c < 91) { // caso maiuscula
                p = (char) (c - chave);
                if ((char) p <= 64) {
                    p = (char) (p + 26);
                }
            } else { // todos os outros caso permanecem com seus caracteres
                // constantes
                p = c;
            }
            String letra = "";
            letra += p;
            descript = descript.concat(letra);
        }
        return descript;
    }
}
