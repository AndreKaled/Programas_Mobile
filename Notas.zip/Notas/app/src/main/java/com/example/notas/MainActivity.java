package com.example.notas;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView aluno1,aluno2,aluno3;
    float nota1,nota2,nota3,mediaNotas;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void calcula(View view){
        aluno1 = findViewById(R.id.aluno1);
        aluno2 = findViewById(R.id.aluno2);
        aluno3 = findViewById(R.id.aluno3);

        nota1 = Float.parseFloat(aluno1.getText().toString());
        nota2 = Float.parseFloat(aluno2.getText().toString());
        nota3 = Float.parseFloat(aluno3.getText().toString());

        mediaNotas = (nota1 + nota2 + nota3)/3;
        atualiza();
    }

    public void atualiza(){
        TextView resultado = findViewById(R.id.media_alunos);
        resultado.setText("Média dos alunos: " +mediaNotas);
    }
}