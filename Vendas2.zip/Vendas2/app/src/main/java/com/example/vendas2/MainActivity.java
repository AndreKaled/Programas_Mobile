package com.example.vendas2;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {


    TextView salarioView, vendasView, taxaComissaoView;
    double salario, vendas, taxaComissao, salarioTotal;
    DecimalFormat df = new DecimalFormat("###,###,#00.00");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    public void calcular(View view){
        salarioView = findViewById(R.id.salario);
        vendasView = findViewById(R.id.valor_total_vendas);
        taxaComissaoView = findViewById(R.id.percentualComissao);

        salario = Double.parseDouble(salarioView.getText().toString());
        vendas = Double.parseDouble(vendasView.getText().toString());
        taxaComissao = Double.parseDouble(taxaComissaoView.getText().toString());

        salarioTotal = salario + (vendas*100 * (taxaComissao/100));

        atualizaTextView();
    }

    public void atualizaTextView(){
        TextView resultado = findViewById(R.id.resultado);
        resultado.setText("Salario de R$:" +df.format(salarioTotal));
    }
}