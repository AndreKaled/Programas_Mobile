package com.example.funcionarios;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class ConsultaFuncionario extends AppCompatActivity {

    ArrayList<Funcionario> listFunc;
    ListView listViewFunc;
    String stringsFunc[];
    ArrayAdapter<String> adaptador;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_consulta_funcionario);

        listViewFunc = (ListView) findViewById(R.id.listaFuncionarios);
        listFunc = (ArrayList<Funcionario>) GerenciaFuncionarios.getList();
        stringsFunc = new String[listFunc.toArray().length];

        carregarListaFuncionarios();

        adaptador = new ArrayAdapter<String>(ConsultaFuncionario.this, android.R.layout.simple_list_item_1, stringsFunc);

        listViewFunc.setAdapter(adaptador);
    }

    private void carregarListaFuncionarios(){
        for(int i=0; i<listFunc.size(); i++){
            stringsFunc[i] = listFunc.get(i).toString();
        }
    }

    public void voltar(View view){
        Intent it = new Intent(ConsultaFuncionario.this, MainActivity.class);
        startActivity(it);
        finish();
    }
}