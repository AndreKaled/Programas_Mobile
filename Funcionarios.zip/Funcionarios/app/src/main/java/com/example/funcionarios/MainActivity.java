package com.example.funcionarios;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    ListView listViewFuncionarios;
    private ListaFuncionariosAdapter listaFuncionariosAdapter;
    private FuncionarioController funcionarioController;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        funcionarioController = FuncionarioController.getInstancia();
        listViewFuncionarios = findViewById(R.id.list);
        listViewFuncionarios.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long id) {
                Funcionario funcionario = funcionarioController.buscarPorPosicao(i);
                funcionarioController.remover(funcionario);
                atualizarLista();
                return true;
            }
        });

        listViewFuncionarios.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent itCadastro = new Intent(MainActivity.this, CadastroFuncionario.class);
                Funcionario funcionario = funcionarioController.buscarPorPosicao(i);
                itCadastro.putExtra("funcionario", funcionario);
                startActivity(itCadastro);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        atualizarLista();
    }

    public void cadastrar(View view){
        iniciarCadastro();
    }

    private void iniciarCadastro() {
        Intent itCadastro = new Intent(MainActivity.this, CadastroFuncionario.class);
        startActivity(itCadastro);
    }

    public void atualizar(View view){

        atualizarLista();
    }

    private void atualizarLista() {
        listaFuncionariosAdapter = new ListaFuncionariosAdapter(MainActivity.this);
        listViewFuncionarios.setAdapter(listaFuncionariosAdapter);
    }

}