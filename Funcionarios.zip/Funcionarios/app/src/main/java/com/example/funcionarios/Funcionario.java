package com.example.funcionarios;

import java.util.Objects;

public class Funcionario {
    private int codigo, idade;
    private String nome, sexo, cargo;

    public Funcionario(int codigo){
        setCodigo(codigo);
    }

    public Funcionario(String nome, String sexo, String cargo, int idade, int codigo){
        setCargo(cargo);
        setCodigo(codigo);
        setNome(nome);
        setSexo(sexo);
        setIdade(idade);
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public String toString(){
        return "nome: "+nome;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Funcionario that = (Funcionario) o;
        return codigo == that.codigo;
    }

    @Override
    public int hashCode() {
        return codigo;
    }
}
