package com.example.funcionarios;

public class CodigoIgualException extends Exception{

    String mensagem;
    int codigo;

    public CodigoIgualException(int codigo){
        mensagem = "Já existe um funcionário com o codigo ";
        this.codigo = codigo;
    }

    public String toString(){
        return mensagem + codigo;
    }
}
