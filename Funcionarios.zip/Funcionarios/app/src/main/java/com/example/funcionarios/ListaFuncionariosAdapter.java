package com.example.funcionarios;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class ListaFuncionariosAdapter extends BaseAdapter {

    Context context;
    List<Funcionario> funcionarios;

    public ListaFuncionariosAdapter(Context context){
        this.context = context;
        FuncionarioController funcionarioController = FuncionarioController.getInstancia();
        this.funcionarios = funcionarioController.buscarTodos();
    }

    @Override
    public int getCount() {
        return funcionarios.size();
    }

    @Override
    public Funcionario getItem(int i) {
        return funcionarios.get(i);
    }

    @Override
    public long getItemId(int i) {
        return getItem(i).getCodigo();
    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {
        View v = LayoutInflater.from(context).inflate(R.layout.item_lista_funcionarios, parent, false);

        TextView textViewNome = v.findViewById(R.id.nome_lista);
        TextView textViewSexo = v.findViewById(R.id.sexo_lista);
        TextView textViewCargo = v.findViewById(R.id.cargo_lista);

        Funcionario funcionario = funcionarios.get(position);
        textViewNome.setText(funcionario.getNome());
        textViewSexo.setText(funcionario.getSexo());
        textViewCargo.setText(funcionario.getCargo());

        return v;
    }
}
