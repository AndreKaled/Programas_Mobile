package com.example.funcionarios;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class CadastroFuncionario extends AppCompatActivity {

    EditText viewNome, viewIdade, viewCodigo, viewCargo;
    Spinner spinnerSexo;
    String nome, cargo, sexo;
    int codigo, idade;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_funcionario);

        viewNome = (EditText) findViewById(R.id.nome);
        viewIdade = (EditText) findViewById(R.id.idade);
        viewCodigo = (EditText) findViewById(R.id.codigo);
        spinnerSexo = findViewById(R.id.sexo);
        viewCargo = (EditText) findViewById(R.id.cargo);
    }

    public boolean verificarCampos(){
        Boolean campoPreenchido = true;
        if(TextUtils.isEmpty(viewNome.getText().toString())){
            viewNome.setError("Preencha o campo nome");
            campoPreenchido = false;
        }else if(TextUtils.isEmpty(viewCargo.getText().toString())){
                viewCargo.setError("Preencha o campo cargo");
                campoPreenchido = false;
        }else if(TextUtils.isEmpty(viewIdade.getText().toString())){
            viewIdade.setError("Preencha o campo idade");
            campoPreenchido = false;
        }else if(TextUtils.isEmpty(viewCodigo.getText().toString())){
            viewCodigo.setError("Preencha o campo código");
            campoPreenchido = false;
        }

        return campoPreenchido;
    }

    public void salvar(View view){
        nome = viewNome.getText().toString();
        cargo = viewCargo.getText().toString();
        sexo = spinnerSexo.getSelectedItem().toString();


       if(verificarCampos()) {
            codigo = Integer.parseInt(viewCodigo.getText().toString());
            idade = Integer.parseInt(viewIdade.getText().toString());

            //codigo = abacate(codigo);

            Funcionario func = new Funcionario(nome, sexo, cargo, idade, codigo);
            GerenciaFuncionarios.add(func);
            Toast.makeText(this, "Salvo com sucesso!", Toast.LENGTH_LONG);
       }
    }

    public void voltar(View view){
        Intent it = new Intent(CadastroFuncionario.this, MainActivity.class);
        startActivity(it);
        finish();
    }

    public void limpar(View view){
        viewNome.setText("");
        viewCargo.setText("");
        viewCodigo.setText("");
        viewIdade.setText("");
    }

    //nao deu certo buabuabua
    public int abacate(int codigo){
        if(GerenciaFuncionarios.verificaCodigosIguais(codigo)){
            Toast.makeText(this, "Código já existente!", Toast.LENGTH_LONG);
        }else{
            return codigo;
        }
        return abacate(codigo+1);
    }
}