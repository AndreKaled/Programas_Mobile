package com.example.funcionarios;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;

public class CadastroFuncionario extends AppCompatActivity {

    EditText viewNome, viewIdade, viewCodigo, viewCargo;
    Spinner spinnerSexo;
    String nome, cargo, sexo;
    int codigo, idade;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_funcionario);

        viewNome = findViewById(R.id.nome);
        viewIdade = findViewById(R.id.idade);
        viewCodigo = findViewById(R.id.codigo);
        spinnerSexo = findViewById(R.id.sexo);
        viewCargo = findViewById(R.id.cargo);
    }

    public boolean verificarCampos(){
        Boolean campoPreenchido = true;
        if(viewNome.getText().toString().isEmpty()){
            viewNome.setError("Preencha o campo nome");
            campoPreenchido = false;
        }
        if(viewIdade.getText().toString().isEmpty()){
            viewIdade.setError("Preencha o campo idade");
            campoPreenchido = false;
        }
        if(viewCodigo.getText().toString().isEmpty()){
            viewCodigo.setError("Preencha o campo código");
            campoPreenchido = false;
        }
        if(viewCargo.getText().toString().isEmpty()){
            viewCargo.setError("Preencha o campo cargo");
            campoPreenchido = false;
        }
        return campoPreenchido;
    }

    public void salvar(View view){
        nome = viewNome.getText().toString();
        cargo = viewCargo.getText().toString();
        sexo = spinnerSexo.getOnItemSelectedListener().toString();
        codigo = Integer.parseInt(viewCodigo.getText().toString());
        idade = Integer.parseInt(viewIdade.getText().toString());

        if(verificarCampos()){
            Funcionario func = new Funcionario(nome, sexo, cargo, idade, codigo);
            GerenciaFuncionarios.add(func);
        }
    }

    public void voltar(View view){
        Intent it = new Intent(CadastroFuncionario.this, MainActivity.class);
        startActivity(it);
    }

    public void limpar(View view){
        viewNome.setText("");
        viewCargo.setText("");
        viewCodigo.setText("");
        viewIdade.setText("");
    }
}