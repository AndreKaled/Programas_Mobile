package com.example.funcionarios;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;

public class CadastroFuncionario extends AppCompatActivity {

    EditText viewNome, viewIdade, viewCodigo, viewCargo;
    Spinner spinnerSexo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_funcionario);
    }

    public void salvar(View view){

    }

    public void voltar(View view){

    }
}