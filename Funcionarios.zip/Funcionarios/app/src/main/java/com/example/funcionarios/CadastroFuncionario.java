package com.example.funcionarios;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class CadastroFuncionario extends AppCompatActivity {
    EditText viewNome, viewIdade, viewCargo;
    Spinner spinnerSexo;
    String nome, cargo, sexo;
    int idade;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_funcionario);

        viewNome = (EditText) findViewById(R.id.nome);
        viewIdade = (EditText) findViewById(R.id.idade);
        spinnerSexo = findViewById(R.id.sexo);
        viewCargo = (EditText) findViewById(R.id.cargo);

        Intent it = getIntent();
        if(it.hasExtra("funcionario")) {
            Funcionario funcionario = (Funcionario) it.getSerializableExtra("funcionario");
            viewNome.setText(funcionario.getNome());
            viewIdade.setText(funcionario.getIdade());
            viewCargo.setText(funcionario.getCargo());
        }
    }

    public boolean verificarCampos(){
        Boolean campoPreenchido = true;
        if(TextUtils.isEmpty(viewNome.getText().toString())){
            viewNome.setError("Preencha o campo nome");
            campoPreenchido = false;
        }else if(TextUtils.isEmpty(viewCargo.getText().toString())){
            viewCargo.setError("Preencha o campo cargo");
            campoPreenchido = false;
        }else if(TextUtils.isEmpty(viewIdade.getText().toString())){
            viewIdade.setError("Preencha o campo idade");
            campoPreenchido = false;
        }

        return campoPreenchido;
    }

    public void salvar(View view){
        nome = viewNome.getText().toString();
        cargo = viewCargo.getText().toString();
        sexo = spinnerSexo.getSelectedItem().toString();


        if(verificarCampos()) {
            idade = Integer.parseInt(viewIdade.getText().toString());
            Funcionario func = new Funcionario(nome, sexo, cargo, idade);
            FuncionarioController.getInstancia().cadastrar(func);
            Toast.makeText(this, "Salvo com sucesso!", Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(this, "Ocorreu algum erro :(", Toast.LENGTH_SHORT).show();
        }

        /* teste de log
        for (Funcionario f: GerenciaFuncionarios.getList()) {
            Log.println(Log.INFO, "func", f.toString());
        }
        */
        voltar();
    }

    public void voltar(){
        Intent it = new Intent(CadastroFuncionario.this, MainActivity.class);
        startActivity(it);
        finish();
    }
}