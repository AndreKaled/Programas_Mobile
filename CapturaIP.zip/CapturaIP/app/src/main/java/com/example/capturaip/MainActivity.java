package com.example.capturaip;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import java.net.UnknownHostException;

public class MainActivity extends AppCompatActivity {

    IP ip;
    TextView nomeView, localView, globalView, loopView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nomeView = findViewById(R.id.nome);
        localView = findViewById(R.id.IP_Local);
        globalView = findViewById(R.id.IP_global);
        loopView = findViewById(R.id.loopback);

        try {
            ip = new IP();
            captura(ip);
            Toast.makeText(this, "Capturado com sucesso", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Erro ao capturar", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }

    private void captura(IP ip){
        nomeView.setText(nomeView.getText() +" " +ip.nomeMaquina);
        localView.setText(localView.getText() +" " +ip.ipLocal);
        loopView.setText(nomeView.getText() +" " +ip.loopback);
        globalView.setText(nomeView.getText() +" " +ip.ipGlobal);
    }
}