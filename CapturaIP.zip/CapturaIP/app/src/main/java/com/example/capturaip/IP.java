package com.example.capturaip;

import java.net.Inet6Address;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;

public class IP {
    String ipLocal, nomeMaquina, loopback, ipGlobal;

    public IP() throws UnknownHostException {
        ipLocal = InetAddress.getLocalHost().getHostAddress();
        nomeMaquina = InetAddress.getLocalHost().getHostName();
        loopback = Inet6Address.getLoopbackAddress().getHostAddress();
        try {
            ipGlobal = new URL("https://api.ipify.org/").getFile();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
    }

    public String getIpLocal() {
        return ipLocal;
    }

    public String getNomeMaquina() {
        return nomeMaquina;
    }

    public String getLoopback() {
        return loopback;
    }

    public String getIpGlobal() {
        return ipGlobal;
    }
}
