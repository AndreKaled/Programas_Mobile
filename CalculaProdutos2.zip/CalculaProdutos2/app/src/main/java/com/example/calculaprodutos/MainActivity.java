package com.example.calculaprodutos;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    TextView precoView;
    TextView quantView;
    double preco;
    double quantidade;
    double resultado;
    DecimalFormat df = new DecimalFormat("0.00");
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void calcular(View view){
        precoView = findViewById(R.id.editTextNumber);
        quantView = findViewById(R.id.editTextNumber2);

        preco = Float.parseFloat(precoView.getText().toString());
        quantidade = Float.parseFloat(quantView.getText().toString());
        resultado = preco*quantidade;
        atualiza();
    }
    public void atualiza(){
        TextView total = findViewById(R.id.textView);
        total.setText("Preço total: " +df.format(resultado));
    }
}