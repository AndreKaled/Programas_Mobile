package com.example.circulo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    private EditText posicaoX, posicaoY, raio;
    private TextView resultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        posicaoX = findViewById(R.id.posicao_x);
        posicaoY = findViewById(R.id.posicao_y);
        raio = findViewById(R.id.relampago);
        resultado = findViewById(R.id.raio);
    }

    public void calcularArea(View view){
        Circulo circ = new Circulo(Double.parseDouble(raio.getText().toString()),Integer.parseInt(posicaoX.getText().toString()),
                Integer.parseInt(posicaoY.getText().toString()));
        DecimalFormat df = new DecimalFormat("Raio do círculo: 0.00");
        resultado.setText(df.format(circ.calculaArea()));
    }
}