package com.example.circulo;

public class Circulo {
    private double area, raio;
    private int posicaoX, posicaoY;

    public Circulo() {
    }

    public Circulo(double raio, int x, int y){
        setPosicaoX(x);
        setPosicaoY(y);
        setRaio(raio);
    }

    public double calculaArea(){
        area = raio*Math.pow(Math.PI,2);
        return area;
    }

    public double calculaArea(double raio){
        area = raio*Math.pow(Math.PI,2);
        return area;
    }

    public double getArea() {
        return area;
    }

    public void setArea(double area) {
        this.area = area;
    }

    public double getRaio() {
        return raio;
    }

    public void setRaio(double raio) {
        this.raio = raio;
    }

    public int getPosicaoX() {
        return posicaoX;
    }

    public void setPosicaoX(int posicaoX) {
        this.posicaoX = posicaoX;
    }

    public int getPosicaoY() {
        return posicaoY;
    }

    public void setPosicaoY(int posicaoY) {
        this.posicaoY = posicaoY;
    }
}
