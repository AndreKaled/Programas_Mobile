package com.example.pesoideal;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    TextView alturaPessoaText;
    Float pesoIdeal, alturaPessoa;
    Spinner sexoPessoa;
    String sexo, selected;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final String[] operacoes = {"Masculino", "Feminino"};
        Spinner spin = findViewById(R.id.sexoPessoa);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, operacoes);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spin.setAdapter(adapter);

        spin.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int position, long id) {

                selected = operacoes[position];
                //teste
                Toast.makeText(getApplicationContext(), selected, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        }

    /*public void calcula(View view){
        alturaPessoaText = findViewById(R.id.alturaPessoa);
        sexoPessoa = findViewById(R.id.sexoPessoa);
        sexo = sexoPessoa.getOnItemSelectedListener();
    }*/

    }
}