package com.example.pesoideal;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    private TextView resultado;
    private Spinner spinnerGenero;
    private EditText viewAltura;
    private DecimalFormat df = new DecimalFormat("0.00");
    private static final double constHomem = 72.7, constMulher = 62.1, constMulher2 = 44.7, constHomem2 = 58;
    private double pesoIdeal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        viewAltura = findViewById(R.id.altura);
        spinnerGenero = findViewById(R.id.genero);
    }

    public void calcularPesoIdeal(View view){
        calcula(viewAltura, spinnerGenero);
    }

    private void calcula(EditText viewAltura, Spinner spinnerGenero) {

        double altura = Double.parseDouble(viewAltura.getText().toString());
        String genero = spinnerGenero.getSelectedItem().toString();
        resultado = findViewById(R.id.resultado);

        if(genero.equals("Masculino")){
            pesoIdeal = (constHomem*altura)-constHomem2;
        }else{
            pesoIdeal = (constMulher*altura)-constMulher2;
        }
        resultado.setText("Peso ideal: " +df.format(pesoIdeal));
    }
}