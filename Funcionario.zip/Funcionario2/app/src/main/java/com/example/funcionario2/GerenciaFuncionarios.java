package com.example.funcionario2;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class GerenciaFuncionarios {
    private static List<Funcionario> list = new ArrayList<Funcionario>();

    public static void add(Funcionario func){
        list.add(func);
    }

    public static void remove(Funcionario func){
        list.remove(func);
    }

    public static Funcionario find(int codBusca){
        Funcionario f = new Funcionario(codBusca);
        if(list.contains(codBusca)){
            for (Funcionario func: list) {
                if(func.equals(f)){
                    return func;
                }
            }
        }
        return null;
    }

    public static boolean update(Funcionario funcionario, int cod){
        Funcionario funcionarioEncontrado = find(cod);
        if(funcionario.getCodigo()==cod&&funcionarioEncontrado.getCodigo()==funcionario.getCodigo()){
            list.set(cod, funcionario);
            return true;
        } else
            return false;
    }

    public static List<Funcionario> getList() {
        return list;
    }

    public static boolean verificaCodigosIguais(int cod){
        return list.contains(cod);
    }
}
